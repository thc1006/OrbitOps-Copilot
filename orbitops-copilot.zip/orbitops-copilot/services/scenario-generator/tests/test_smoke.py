"""Sprint 0 smoke test for scenario-generator placeholder."""

from __future__ import annotations

from scenario_generator import list_templates


def test_list_templates_contains_three_known_scenarios() -> None:
    templates = list_templates()
    assert "beam-degradation" in templates
    assert "handover-failure" in templates
    assert "gateway-fallback" in templates
