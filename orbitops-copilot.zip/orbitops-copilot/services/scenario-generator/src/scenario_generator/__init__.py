"""scenario-generator (Sprint 0 placeholder).

Real implementation lands in Sprint 1, slice S1-01.
See: docs/specs/SPEC-001-scenario-generator.md
"""

from __future__ import annotations

__version__ = "0.0.1.dev0"


def list_templates() -> list[str]:
    """Return the list of scenario template names available.

    Sprint 0: returns the names of files in packages/scenarios/.
    Sprint 1 will replace this with template-driven generation.
    """
    return ["beam-degradation", "handover-failure", "gateway-fallback"]
