"""Sprint 0 smoke tests for copilot-api placeholder.

Asserts that the schema-locked /ask stub returns INSUFFICIENT_EVIDENCE
and validates against the canonical Pydantic model.
"""

from __future__ import annotations

from fastapi.testclient import TestClient

from copilot_api.main import app
from copilot_api.models import CopilotResponse


def test_healthz_returns_ok() -> None:
    client = TestClient(app)
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_ask_stub_returns_insufficient_evidence() -> None:
    client = TestClient(app)
    r = client.post("/ask", json={})
    assert r.status_code == 200
    parsed = CopilotResponse.model_validate(r.json())
    assert parsed.status == "INSUFFICIENT_EVIDENCE"
    assert parsed.evidence.metrics_used == []
    assert parsed.evidence.confidence == 0.0
