"""Pydantic models for the copilot response schema.

Conforms to tests/contracts/copilot-response.schema.json.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class MetricUsed(BaseModel):
    name: str
    labels: dict[str, str]
    value: float
    timestamp: datetime


class LogUsed(BaseModel):
    source: str
    line: str
    timestamp: datetime


class Evidence(BaseModel):
    metrics_used: list[MetricUsed] = Field(default_factory=list)
    logs_used: list[LogUsed] = Field(default_factory=list)
    scenario_id: str | None = None
    timestamp: datetime
    confidence: float = Field(ge=0.0, le=1.0)


class RunbookStep(BaseModel):
    step: int = Field(ge=1, le=5)
    title: str
    body: str


CopilotStatus = Literal["ok", "INSUFFICIENT_EVIDENCE", "ERROR"]


class CopilotResponse(BaseModel):
    answer: str | None = None
    runbook: list[RunbookStep] | None = None
    evidence: Evidence
    status: CopilotStatus
    error: str | None = None
