"""FastAPI app entry-point (Sprint 0 placeholder).

Sprint 0 exposes /healthz and a stub /ask that returns INSUFFICIENT_EVIDENCE.
Real /ask, /explain, /runbook implemented in Sprint 1 (S1-04, S1-05).
"""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import FastAPI

from .models import CopilotResponse, Evidence

app = FastAPI(title="copilot-api", version="0.0.1.dev0")


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/ask", response_model=CopilotResponse)
def ask_stub(_: dict | None = None) -> CopilotResponse:
    """Sprint 0: always returns INSUFFICIENT_EVIDENCE.

    Real implementation in Sprint 1 will RAG over Prometheus + mock logs.
    """
    return CopilotResponse(
        answer=None,
        runbook=None,
        evidence=Evidence(
            metrics_used=[],
            logs_used=[],
            scenario_id=None,
            timestamp=datetime.now(timezone.utc),
            confidence=0.0,
        ),
        status="INSUFFICIENT_EVIDENCE",
        error="Sprint 0: copilot-api not yet implemented (S1-04/S1-05).",
    )
