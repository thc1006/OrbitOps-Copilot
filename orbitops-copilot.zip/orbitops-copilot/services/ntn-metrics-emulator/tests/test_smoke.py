"""Sprint 0 smoke test for emulator placeholder."""

from __future__ import annotations

from fastapi.testclient import TestClient

from ntn_metrics_emulator.main import app


def test_healthz_returns_ok() -> None:
    client = TestClient(app)
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}
