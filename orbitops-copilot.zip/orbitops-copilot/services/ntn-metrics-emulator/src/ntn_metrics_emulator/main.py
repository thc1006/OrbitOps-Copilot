"""FastAPI app entry-point (Sprint 0 placeholder).

Provides only /healthz; /metrics + /scenarios/* land in Sprint 1.
"""

from __future__ import annotations

from fastapi import FastAPI

app = FastAPI(title="ntn-metrics-emulator", version="0.0.1.dev0")


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}
