---
name: runspace-pitch
description: Build / refine RunSpace pitch artifacts (10-page deck, 90s + 3min videos). Enforces anonymity.
---

# runspace-pitch skill

## When to use

Whenever editing `docs/06_runspace_pitch_outline.md`, `docs/07_demo_script_90s.md`, `docs/08_demo_script_3min.md`, or producing recording scripts / slide content.

## Procedure

1. Pull narrative beats from `docs/01_product_strategy.md` (UC1/UC2 + demo story).
2. Anchor in standards/programs cited in `docs/00_research_2026_04.md`.
3. Differentiation table from `docs/00_research_2026_04.md` §3.
4. Roadmap from `docs/03_breakthrough_directions.md`.
5. Cite each external claim with footnote URL drawn from `docs/10_links.md`.

## Anonymity hard rules

- No team / school / personal identifiers in slides, scripts, or rendered videos.
- Hide OS toolbar, terminal username, browser tabs in demo recordings.
- After export, run `exiftool -all= <file>` on PDF/MP4.
- UI footer must NOT contain "Built by ..." attribution; only project name.

## Reference

- RunSpace official rules (verify before submission)
- Two scoring frames in `docs/00_research_2026_04.md` §5 (30/30/30/10 and 35/25/20/20)
