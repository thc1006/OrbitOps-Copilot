---
name: k8s-demo
description: Cloud-native demo workflow — bring up kind/k3d, apply Kustomize, smoke test, tear down. Use when iterating on deploy/.
---

# k8s-demo skill

## When to use

When working on `deploy/k8s/`, `deploy/helm/`, `deploy/kind/`, `deploy/k3d/`, or `packages/nephio-stubs/`.

## Procedure

1. `make kind-up` — create local cluster (config: `deploy/kind/cluster.yaml`).
2. `make k8s-apply` — kustomize build + kubectl apply --dry-run=client.
3. After Sprint 1+: drop --dry-run, watch pods until Ready (≤ 90s).
4. `make k8s-smoke` — curl healthz endpoints from inside cluster.
5. `make kind-down` — destroy cluster cleanly.

## Hard rules

- Never `:latest` tags.
- Always set requests/limits + probes.
- No NodePort to public networks.
- Nephio: stub only (per ADR-005).

## Reference

- `docs/specs/SPEC-006-k8s-deployment.md`
- `docs/adr/ADR-005-nephio-stub-first.md`
