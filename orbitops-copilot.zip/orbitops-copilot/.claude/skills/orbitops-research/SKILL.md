---
name: orbitops-research
description: Authoritative source-cited research workflow for B5G/NTN, 3GPP, Nephio, AI-RAN, NVIDIA Aerial. Use when adding new facts to docs/00 or docs/10.
---

# orbitops-research skill

## When to use

Whenever Claude is asked to verify or add a fact about: TASA B5G LEO, CesiumAstro, YTTEK, 3GPP releases, Nephio, O-RAN, NVIDIA Aerial / AODT / Sionna RT, AI-RAN Alliance, OSS RAN/5GC tools (srsRAN, OAI, UERANSIM, free5GC, Open5GS), observability stack, or LLM tooling.

## Workflow

1. WebSearch primary sources first; WebFetch for deeper read.
2. Prefer official URLs (`tasa.org.tw`, `3gpp.org`, `docs.nephio.org`, `o-ran.org`, `developer.nvidia.com`, GitHub releases pages).
3. For each fact: 1-sentence claim + URL + date + confidence + implication.
4. Append to `docs/00_research_2026_04.md`; add URL to `docs/10_links.md`.
5. If a fact concerns a specific version, run the verification command (e.g., `gh api repos/OWNER/REPO/releases/latest`) and pin the tag in `docs/09_installation_research.md`.
6. Anonymity: cite only public organizations; never team / school / personal identifiers.

## Reference

- `docs/00_research_2026_04.md` — research entries
- `docs/09_installation_research.md` — verified versions
- `docs/10_links.md` — allowlist of external URLs
