# Backlog

> 每個 item 為 vertical slice（spec + test + code + docs + demo screenshot 全綠）。1–2 天可完成。

## Sprint 0（已完成 — bootstrap）

- [x] 建立 repo 骨架、CLAUDE.md、AGENTS.md
- [x] Phase 1 研究文件（`docs/00_research_2026_04.md`）
- [x] Phase 2 docs 01–05 框架
- [x] SDD/TDD/Agile 工程憲法寫入
- [x] SPEC-000~007、AC-001~004、ADR-001~005
- [x] tests/contracts JSON schemas、tests/golden expected
- [x] verify.sh / test.sh / Makefile / CI

## Sprint 1（P0 — 核心 vertical slice）

- [ ] **S1-01** scenario-generator：`generate(template)` 產 3 個 sample scenarios → schema 驗證通過。 (1d, ran-ntn)
- [ ] **S1-02** ntn-metrics-emulator：`/healthz`、`/metrics` 暴露 5 個核心 gauge → contract test。 (1d, ran-ntn + obs)
- [ ] **S1-03** ntn-metrics-emulator：scenario load + tick loop → golden replay test。 (1d, ran-ntn)
- [ ] **S1-04** copilot-api：`/healthz`、`MockProvider`、Pydantic evidence schema → unit + grounding test。 (1d, llm)
- [ ] **S1-05** copilot-api：`/explain` + `/runbook` 5-step → AC-002 通過。 (2d, llm)
- [ ] **S1-06** UI shell：Vite + React + Tailwind + 路由 + Copilot panel（call `/ask`）→ build 通過。 (1d, arch)
- [ ] **S1-07** Prometheus + Grafana：scrape config + dashboard JSON → docker-compose 可跑。 (1d, obs)
- [ ] **S1-08** docker-compose：emulator + copilot + ui + prom + grafana → `make dev-up` 全綠。 (1d, k8s)
- [ ] **S1-09** kind cluster + Kustomize base → `make kind-up && make k8s-apply` 通過。 (1d, k8s)
- [ ] **S1-10** Demo replay script + tmp/demo-output.json → AC-004 通過。 (1d, arch)

## Sprint 2（P0 完整 + P1 起頭）

- [ ] **S2-01** anomaly injection 真實作（前一階段為 stub）。
- [ ] **S2-02** UI：Recharts 顯示 SNR / latency time-series。
- [ ] **S2-03** Helm chart skeleton → `helm template` 通過。
- [ ] **S2-04** Loki integration（mock logs）。
- [ ] **S2-05** OpenAI-compatible adapter + Ollama smoke test。
- [ ] **S2-06** ArgoCD App YAML（不需 mgmt cluster）。
- [ ] **S2-07** voice-interface stub（faster-whisper 接口）。

## Sprint 3（P1 / 簡報）

- [ ] **S3-01** CesiumJS satellite pass 動畫。
- [ ] **S3-02** RunSpace 10-page slide draft。
- [ ] **S3-03** 90 秒 demo 影片腳本走過 + 錄製。
- [ ] **S3-04** 3 分鐘英文字幕影片。
- [ ] **S3-05** Nephio kpt package stub 文件化。

## Backlog（暫不排）

- 真 OAI / srsRAN wrapper
- Sionna RT channel coefficients 注入
- AODT 整合（待 OSS 上線）
- closed-loop GitOps reconcile
- Multi-language UI

---

## 規格／驗收／ADR 對應表

| Slice | SPEC | AC | ADR |
|---|---|---|---|
| S1-01 | 001 | 004 | 001 |
| S1-02/03 | 002 | 001/002/004 | 001/003 |
| S1-04/05 | 003 | 001/002/003 | 004 |
| S1-06 | 004 | 001/002 | 002 |
| S1-07 | 005 | 001/002 | 003 |
| S1-08/09 | 006 | 004 | 001/005 |
| S1-10 | 007 | 004 | — |
