# Sprint 1 — P0 Core Vertical Slice

| 欄位 | 值 |
|---|---|
| Duration | 1 週 |
| Goal | 完成 P0 demo loop：scenario → emulator → copilot → UI → docker-compose 跑通 |

## Scope（10 slices；見 backlog S1-01 ~ S1-10）

每個 slice 一份 sub-PR：
1. **S1-01** scenario-generator MVP
2. **S1-02** emulator `/healthz` + `/metrics`
3. **S1-03** emulator scenario tick loop
4. **S1-04** copilot-api MockProvider + schema
5. **S1-05** copilot-api `/explain` + `/runbook`
6. **S1-06** UI shell + Copilot panel
7. **S1-07** Prometheus + Grafana
8. **S1-08** docker-compose 全綠
9. **S1-09** kind + Kustomize 通過
10. **S1-10** demo replay（AC-004 通過）

## Acceptance（Sprint exit）

- AC-001、AC-002、AC-003、AC-004 自動測試全綠
- `make verify` 全綠
- `scripts/run-demo.sh` 跑出 `tmp/demo-output.json` 通過 schema
- README 可重現安裝 / dev-up

## Risks（從 risk-register 引用）

- R-01 LLM 幻想：以 mock provider 為 Sprint 1 預設
- R-04 版本漂移：`verify.sh` 在每個 PR 跑

## Demo

於 sprint review 用 `scripts/run-demo.sh` 走過一次 + screenshot Grafana dashboard。
