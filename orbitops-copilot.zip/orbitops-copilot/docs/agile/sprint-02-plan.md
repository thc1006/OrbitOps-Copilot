# Sprint 2 — P0 完整 + P1 起頭

| 欄位 | 值 |
|---|---|
| Duration | 1 週 |
| Goal | UI 視覺化升級、Helm chart、真 LLM 接入、ArgoCD demo |

## Scope（見 backlog S2-01 ~ S2-07）

1. **S2-01** anomaly injection 真實作
2. **S2-02** UI Recharts 時序圖
3. **S2-03** Helm chart skeleton → `helm template` 通過
4. **S2-04** Loki integration
5. **S2-05** OpenAI-compatible adapter + Ollama smoke
6. **S2-06** ArgoCD App YAML
7. **S2-07** voice-interface stub

## Acceptance

- AC-001/002/003/004 仍綠
- `helm template` 與 `helm install --dry-run` 通過
- 至少跑過一次真 LLM endpoint（Ollama + Qwen3.6-27B）

## Demo

real LLM 模式錄一次 90 秒 demo。
