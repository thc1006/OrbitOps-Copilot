# Sprint 3 — P1 + 簡報

| 欄位 | 值 |
|---|---|
| Duration | 1 週 |
| Goal | CesiumJS 動畫、簡報、影片 |

## Scope（見 backlog S3-01 ~ S3-05）

1. CesiumJS satellite pass 動畫
2. 10-page RunSpace slide draft
3. 90-second demo video
4. 3-minute English-subtitled video
5. Nephio kpt package stub 文件化

## Acceptance

- 所有提交檔通過 `scripts/check-no-secrets.sh`（含匿名性檢查）
- 影片 metadata（exiftool）無作者欄位
- 簡報無團隊／學校／姓名／Logo

## Demo

提交前 dry-run 一次 RunSpace 評審情境。
