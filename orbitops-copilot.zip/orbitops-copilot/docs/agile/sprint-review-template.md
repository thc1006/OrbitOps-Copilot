# Sprint Review — Sprint NN

| 欄位 | 值 |
|---|---|
| Sprint | NN |
| Dates | YYYY-MM-DD ~ YYYY-MM-DD |
| Facilitator | <role> |

## What we shipped

- [ ] item 1
- [ ] item 2

## What we did NOT ship（and why）

- item / reason

## Metrics

- AC pass rate: X / Y
- `make verify` green: yes/no
- New issues opened: N

## Demo

Link to demo recording or `scripts/run-demo.sh` output snapshot.

## Retrospective

| Continue | Stop | Start |
|---|---|---|
| | | |

## Action items

- [ ] action — owner — due

## Next sprint adjustments

…
