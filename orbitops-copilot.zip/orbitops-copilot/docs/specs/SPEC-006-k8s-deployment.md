# SPEC-006 — k8s-deployment

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | k8s-platform-engineer |

## Goal

整套 demo 可部署到 local kind/k3d/minikube 與遠端 Kubernetes。第一版用 Kustomize；Helm chart 為發行管道。Nephio kpt package 為 stub（demonstrate intent，不跑 Porch）。

## Layout

- `deploy/k8s/base/`：所有 service Deployment + Service + ConfigMap。
- `deploy/k8s/overlays/local/`：local namespace、rsrc limits、image pull policy。
- `deploy/helm/orbitops-copilot/`：chart skeleton。
- `deploy/kind/cluster.yaml`、`deploy/k3d/cluster.yaml`：local cluster 配置。
- `deploy/docker-compose.yml`：dev fast-path（不依賴 K8s）。
- `packages/nephio-stubs/orbitops-groundstation-package/`：kpt package skeleton。

## Constraints

- 所有 image tag 不得為 `:latest`；用 `:0.0.1-dev` 或 commit SHA。
- 必須有 `resources.requests` / `resources.limits`。
- 必須有 `livenessProbe` 與 `readinessProbe`。
- 不開 NodePort 對外網；port-forward / Ingress（P1）。
- `kustomize build deploy/k8s/overlays/local | kubectl apply --dry-run=client` 須通過。

## Non-goals

- 不做完整 O2 IMS lifecycle。
- 不跑 Porch / FOCOM。
- 不做 multi-cluster。

## Acceptance

- AC-004 之 k8s smoke 部分。
