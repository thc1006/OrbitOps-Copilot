# SPEC-007 — runspace-demo

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | architect |

## Goal

在 RunSpace 初審 / 決賽中可重現的 demo 體驗：90 秒影片 + 3 分鐘英文字幕影片 + 10 頁簡報 + 一個 live demo session。

## Deliverables

- `docs/06_runspace_pitch_outline.md`：10 頁簡報大綱。
- `docs/07_demo_script_90s.md`：90 秒腳本。
- `docs/08_demo_script_3min.md`：3 分鐘腳本（含英文字幕時間軸）。
- `scripts/run-demo.sh`：自動執行 golden scenario → 載入 → 觸發 anomaly → 詢問 copilot → 顯示 evidence。

## Constraints

- **匿名**：影片不出現團隊／學校／姓名／Logo；錄製時隱藏 OS toolbar。
- 任何畫面截圖前須過 `scripts/check-no-secrets.sh`。
- 影片字幕純英文；簡報純英文。

## Non-goals

- 不做配音演員或商業級剪輯（投影片+screen capture 即可）。

## Acceptance

- AC-004（Demo Replay）。
