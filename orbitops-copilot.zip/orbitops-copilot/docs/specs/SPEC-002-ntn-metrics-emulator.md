# SPEC-002 — ntn-metrics-emulator

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | ran-ntn-engineer + observability-engineer |
| Depends on | SPEC-001 |

## Goal

讀入 scenario JSON，依時間軸生成 NTN 域內 metrics，並以 Prometheus exposition format 暴露 `/metrics`。可即時注入新的 anomaly。

## Metrics（schema：`tests/contracts/metrics.schema.json`）

| Name | Type | Labels | Unit | 說明 |
|---|---|---|---|---|
| `orbitops_snr_db` | Gauge | `beam_id`, `gateway_id`, `scenario_id` | dB | 訊噪比 |
| `orbitops_sinr_db` | Gauge | 同上 | dB | 含干擾訊噪比 |
| `orbitops_latency_ms` | Gauge | `path`, `beam_id` | ms | end-to-end |
| `orbitops_packet_loss_ratio` | Gauge | `beam_id` | ratio (0–1) | 丟包率 |
| `orbitops_doppler_residual_hz` | Gauge | `beam_id` | Hz | 補償後殘差 |
| `orbitops_elevation_deg` | Gauge | `beam_id` | deg | 仰角 |
| `orbitops_handover_state` | Gauge | `beam_id`, `state` | 0/1 | one-hot |
| `orbitops_handover_failures_total` | Counter | `beam_id`, `cause` | count | |
| `orbitops_pod_health` | Gauge | `pod`, `namespace` | 0/1 | mock pod health |
| `orbitops_anomaly_active` | Gauge | `type`, `target` | 0/1 | 是否注入中 |

## Interfaces

- HTTP：
  - `GET /metrics` → Prometheus exposition
  - `GET /healthz` → `{"status":"ok"}`
  - `POST /scenarios/load` → 載入新 scenario JSON
  - `POST /anomaly/inject` → 即時注入 anomaly
  - `GET /scenarios/current` → 目前 scenario

- 環境變數：
  - `ORBITOPS_SCENARIO_PATH`（預設 `/scenarios/beam-degradation.json`）
  - `ORBITOPS_TICK_SECONDS`（預設 1）
  - `ORBITOPS_LOG_LEVEL`（預設 `info`）

## Constraints

- 純函式內核：`(scenario, t) -> metrics_snapshot` 必須是 deterministic（相同輸入 → 相同輸出，除了刻意的 random anomaly 帶 seed）。
- 啟動 < 3s；單 tick < 50 ms。
- 不寫盤；scenario 從 volume / configmap 讀。

## Non-goals

- 不做真 RF 模擬；不做 ray tracing。
- 不接 LLM。

## Risks

- 指標名稱漂移 → 由 contract test 鎖定（`tests/contracts/metrics.schema.json`）。

## Acceptance

- AC-001、AC-002、AC-004 之 metrics 部分。
