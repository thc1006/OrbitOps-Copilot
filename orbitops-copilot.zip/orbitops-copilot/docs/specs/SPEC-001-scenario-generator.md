# SPEC-001 — scenario-generator

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | ran-ntn-engineer |
| Depends on | SPEC-000 |

## Goal

產出 satellite pass、beam profile、handover event、anomaly injection 的 scenario JSON，作為 `ntn-metrics-emulator` 與 golden test 共同消費的真值來源。

## Inputs

- pass window（start / end UTC、station lat/lon、satellite TLE 或 stub orbit）
- beam profile（beam_id × 3、boresight、HPBW、EIRP stub）
- anomaly injection（type、t_offset、duration、severity）

## Outputs（schema：`tests/contracts/scenario.schema.json`）

```json
{
  "scenario_id": "beam-degradation-001",
  "version": "1.0",
  "description": "string",
  "pass_window": { "start": "ISO8601", "end": "ISO8601" },
  "ground_station": { "id": "gs-tw-01", "lat": 24.78, "lon": 120.99, "alt_m": 50 },
  "satellite": { "id": "b5g-1a", "tle_line1": "...", "tle_line2": "...", "payload_mode": "transparent|regenerative" },
  "beams": [
    { "beam_id": "beam-1", "boresight_az_deg": 120, "boresight_el_deg": 45, "hpbw_deg": 3.5 }
  ],
  "anomaly_injection": [
    { "type": "snr_drop", "t_offset_s": 60, "duration_s": 90, "target": "beam-1", "magnitude_db": 6 }
  ],
  "expected_runbook_keywords": ["beam-1", "handover", "elevation"]
}
```

## Interfaces

- CLI：`python -m scenario_generator generate --template beam-degradation --out packages/scenarios/beam-degradation.json`
- Python API：`scenario_generator.generate(template: str) -> Scenario`
- HTTP（optional, P1）：`POST /scenarios/generate`

## Constraints

- 每個 scenario 通過 `tests/contracts/scenario.schema.json` 驗證。
- 不依賴外部時間源；pass window 為輸入或可由 stub TLE 推算。
- `payload_mode` 必須為 `transparent` 或 `regenerative`（Rel-19 用詞）。

## Non-goals

- 不模擬真實衛星軌跡傳播（P2 才接 Skyfield/SGP4 高保真）。
- 不產生 RF channel coefficients（P2 由 Sionna RT）。

## Risks

- 命名與 3GPP Rel-19 漂移 → 由 ran-ntn-engineer 校對。

## Acceptance

- AC-004（Demo Replay）：3 個 sample scenarios 可被 emulator 重播並產生預期 metrics 變化。
