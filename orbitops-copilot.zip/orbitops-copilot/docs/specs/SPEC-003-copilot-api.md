# SPEC-003 — copilot-api

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | llm-copilot-engineer |
| Depends on | SPEC-002 |

## Goal

提供 LLM-backed operations copilot HTTP API，從 Prometheus / mock logs 取證據，產出 anomaly explanation 與 runbook。**所有回應必附 evidence block**；缺證據時回 `INSUFFICIENT_EVIDENCE`。

## Endpoints

| Method | Path | 說明 |
|---|---|---|
| GET | `/healthz` | health probe |
| POST | `/ask` | 自由文字問答（內部會自動拉 metrics 上下文） |
| POST | `/explain` | 給 anomaly id → 解釋 |
| POST | `/runbook` | 給 anomaly id → 5-step runbook |
| GET | `/providers` | 列出已配置的 LLM provider |

## Response schema（`tests/contracts/copilot-response.schema.json`）

```json
{
  "answer": "string",
  "runbook": [
    {"step": 1, "title": "What happened?", "body": "..."},
    {"step": 2, "title": "Why it matters?", "body": "..."},
    {"step": 3, "title": "Recommended action", "body": "..."},
    {"step": 4, "title": "Risk if ignored", "body": "..."},
    {"step": 5, "title": "Next observation window", "body": "..."}
  ],
  "evidence": {
    "metrics_used": [{"name": "orbitops_snr_db", "labels": {"beam_id": "beam-1"}, "value": 4.2, "timestamp": "ISO8601"}],
    "logs_used": [{"source": "mock-pod-bus-1", "line": "...", "timestamp": "ISO8601"}],
    "scenario_id": "beam-degradation-001",
    "timestamp": "ISO8601",
    "confidence": 0.0
  },
  "status": "ok | INSUFFICIENT_EVIDENCE | ERROR",
  "error": "string?"
}
```

## Provider abstraction

- `LlmProvider` interface：`chat(messages, schema) -> dict`
- 內建：
  - `MockProvider`（測試/離線；依 evidence 樣板生成回應）
  - `OpenAICompatibleProvider`（環境變數 `OPENAI_BASE_URL`、`OPENAI_MODEL`、`OPENAI_API_KEY`，相容 Ollama / vLLM / LM Studio / 真 OpenAI）

## Constraints

- 不允許 user input 直接拼接進 system prompt；需透過 `{evidence}` 與 `{question}` placeholder。
- Schema-validated output：模型回應必須通過 Pydantic 驗證；否則 retry 1 次後降級為 `INSUFFICIENT_EVIDENCE`。
- Token budget：context 上限 8k tokens（可配置）；超過則摘要 metrics window。

## Non-goals

- 不做 multi-turn long-running agent。
- 不做工具呼叫（function calling 留 P1）。
- 不存使用者個資。

## Risks

- Prompt injection → mitigation：sanitize、template、JSON-mode、output schema 驗證。
- 模型幻想 → mitigation：強制 evidence block、grounding test、低溫度（temperature ≤ 0.3）。

## Acceptance

- AC-001、AC-002、AC-003。
