# SPEC-004 — digital-twin-ui

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | architect + observability-engineer |
| Depends on | SPEC-002, SPEC-003 |

## Goal

提供 web UI 視覺化 satellite pass、ground station、beam、handover state、anomaly banner、copilot panel。P0 為 UI shell（佈局 + 狀態顯示 + Copilot 面板）；P1 加 CesiumJS satellite pass 動畫。

## Stack

- React 19 + Vite 8 + TypeScript 6 + Tailwind 4
- 視覺化：CesiumJS 1.140（主）/ Three.js r184（備）
- 圖表：Recharts
- HTTP client：fetch（內建）+ tanstack-query optional

## Pages

| Path | 內容 |
|---|---|
| `/` | Dashboard：pass window、active beam、anomaly banner、Copilot panel |
| `/scenario/:id` | scenario 詳情 |
| `/copilot` | 全屏 Copilot 對話（含 evidence block） |
| `/about` | 版本、來源、許可（匿名） |

## Constraints

- 不可硬編 backend URL；用 `VITE_API_BASE_URL`（預設 `http://localhost:8000`）。
- `console.error` 統一收斂到 `src/utils/logger.ts`。
- 不允許 `any`；錯誤型別 `ApiError`。
- 所有字串 i18n（`en` 為主，留 zh-TW 槽位）。

## Non-goals

- P0 不接真 CesiumJS satellite pass；以 Recharts time-series 與 status badge 即可。
- 不做 user auth（demo 沙箱）。

## Acceptance

- AC-001（UI 可呈現 beam quality）、AC-002（UI 可呈現 handover/fallback banner）、AC-004（demo replay 可從 UI 觸發）。
