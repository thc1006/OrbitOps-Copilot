# SPEC-005 — observability

| 項目 | 內容 |
|---|---|
| Status | Draft |
| Owner | observability-engineer |
| Depends on | SPEC-002 |

## Goal

以 Prometheus + Grafana 監控 emulator 與 copilot；30 秒內 anomaly 在 dashboard 可見。Loki/Tempo 為 P1。

## Scrape targets（`observability/prometheus/prometheus.yml`）

- `ntn-metrics-emulator:8000/metrics`（每 5s）
- `copilot-api:8001/metrics`（每 15s）

## Dashboards（`observability/grafana/dashboards/`）

- `orbitops-overview.json`：
  - Pass window timeline
  - Beam SNR/SINR（per `beam_id`）
  - Latency / packet loss
  - Doppler residual
  - Handover state（state machine view）
  - Active anomalies
  - Pod health

## Alerting

- P0：不啟用 alertmanager；以 dashboard 可見即可。
- P1：rules 寫於 `observability/prometheus/rules/orbitops.rules.yml`，例：`orbitops_snr_db < 5 for 30s` → warning。

## Constraints

- dashboard JSON 須通過 Grafana 13 schema 驗證（`grafana-cli` 載入測試）。
- `promtool check rules` 通過。

## Acceptance

- AC-001、AC-002 之 dashboard 部分。
