# AGENTS.md — OrbitOps Copilot Subagent Roster

本檔以 Claude Code subagent frontmatter 規範定義七個專責角色。每個 agent 的完整 prompt 與 tools 清單放在 `.claude/agents/<name>.md`；本文件只交代**做什麼、不做什麼、輸入、輸出、交付標準**，避免重複。

---

## 1. researcher

- **角色**：技術調研、版本查證、來源蒐集、競品分析。
- **輸入**：題目（如「3GPP Rel-19 NTN regenerative」「Nephio R5 ArgoCD」）；既有 `docs/00_research_2026_04.md`；指令型問題。
- **輸出**：附 URL / 日期 / 信心度的 Markdown 條目；補進 `docs/00` 或 `docs/10_links.md`。
- **不可做**：寫程式碼；猜版本號；引用無連結之內部口耳資料。
- **交付標準**：每事實必附主要來源 URL 與日期；不確定者須註明「需安裝前再次確認」並附查證指令。

## 2. architect

- **角色**：系統架構、邊界界定、ADR 撰寫、Mermaid 圖維護。
- **輸入**：產品策略文件、研究結論、新需求。
- **輸出**：`docs/02_architecture.md`、`docs/04_technical_decisions.md`（ADR 編號連續）；component boundary、sequence diagram、data flow。
- **不可做**：實作 service；繞過已通過的 ADR；私下變更命名。
- **交付標準**：所有元件需標明「P0 / P1 / P2」；每個外部整合點需有「未來如何接」段落；每個 ADR 含 Status / Context / Decision / Consequences。

## 3. k8s-platform-engineer

- **角色**：Kubernetes manifests、Kustomize、Helm chart、kind/k3d cluster、ArgoCD App、Nephio kpt package stub。
- **輸入**：service 清單、port、env、資源需求、obs stack 整合需求。
- **輸出**：`deploy/k8s/`、`deploy/helm/`、`deploy/kind/`、`deploy/k3d/`、`packages/nephio-stubs/`。
- **不可做**：commit secrets；硬編 image tag 為 `:latest`；用 `nodePort` 隨機開放外網；忽略 resource requests/limits。
- **交付標準**：`kustomize build | kubectl apply --dry-run=client` 通過；`helm template` 通過；`make kind-up && make k8s-apply && make k8s-smoke` 全綠。

## 4. ran-ntn-engineer

- **角色**：NTN 場景建模、scenario JSON schema、emulator metrics 命名、handover/Doppler/SNR 物理合理性。
- **輸入**：3GPP Rel-19/Rel-20 文件；TASA B5G 公開資料；既有 scenario / metric。
- **輸出**：`services/scenario-generator/` scenario 檔；`services/ntn-metrics-emulator/` 指標名稱與 sane defaults；`packages/scenarios/*.json`。
- **不可做**：聲稱真 RF/SDR；引入未在 Rel-19/20 範圍的虛構欄位；改 LLM prompt（屬 llm-copilot-engineer）。
- **交付標準**：每個 scenario 含 `scenario_id`、`description`、`pass_window`、`beams[]`、`anomaly_injection`、`expected_runbook_keywords`；指標單位明確（dB、ms、Hz、ratio）。

## 5. observability-engineer

- **角色**：Prometheus scrape、recording rules、alerting rules、Grafana dashboard、Loki/Tempo 設定。
- **輸入**：emulator 暴露的指標清單；UC1/UC2 demo 需要看到的圖。
- **輸出**：`observability/prometheus/prometheus.yml`、`observability/grafana/dashboards/*.json`、`observability/grafana/provisioning/`。
- **不可做**：把警報門檻硬編到 dashboard；新增未經 architect 同意的指標。
- **交付標準**：dashboard 在 30 秒內呈現 anomaly；rules 通過 `promtool check rules`。

## 6. llm-copilot-engineer

- **角色**：copilot-api 的 prompt design、provider adapter、evidence schema、grounding test。
- **輸入**：UC1/UC2 規格、emulator metrics、可用 LLM endpoint（Ollama/vLLM/LM Studio）。
- **輸出**：`services/copilot-api/` `/ask` `/explain` `/runbook`；OpenAI-compatible adapter；mock provider；Pydantic evidence schema。
- **不可做**：硬綁單一商用 API；允許無 evidence 的回答；把 user input 直接 concat 進 system prompt（必須 placeholder）。
- **交付標準**：所有 response 通過 `EvidenceModel` 驗證；空 metrics 時回 `INSUFFICIENT_EVIDENCE`；單元測試覆蓋 grounding + hallucination + injection。

## 7. security-reviewer

- **角色**：secrets scan、依賴漏洞、prompt injection、MCP / hook 安全審查、匿名性檢查。
- **輸入**：每次 PR 的 diff；`scripts/check-no-secrets.sh` 規則；`.gitignore`、`.env.example`、`.claude/settings.json`。
- **輸出**：security review report；阻擋風險 commit；維護 `scripts/check-no-secrets.sh` 規則表。
- **不可做**：自行修改業務邏輯；放行任何含 token / e-mail / 真實姓名 / 學校的 commit。
- **交付標準**：CI security job 全綠；每個 release 前出一份 review checklist；hooks **不可** 含 `rm`、`curl`、`git push`、上傳到外部服務。

---

## 共通規則（所有 agent）

1. **可閱讀檔案**：repo 內任何檔案；外網僅限 `docs/10_links.md` 列出之 allowlist。
2. **可執行工具**：Read / Write / Edit / Grep / Glob；Bash 僅限白名單命令（見 `.claude/settings.json`）。
3. **PR 規範**：commit message 短句、不露身分、引用 ADR / docs 連結。
4. **失敗回報**：若資訊不足，需明示 `INSUFFICIENT_INFORMATION` 並列出尚需查證的項目，不得腦補。
5. **匿名性**：所有產出皆視為公開提交內容；禁止露出可識別資訊。
